0x0B. C - malloc, free
Automatic and dynamic allocation, malloc and free