#ifndef MAIN_H
#define MAIN_H
int _putchar(char c);
int main(int argc, char *argv[]);

#endif /* MAIN_H */
