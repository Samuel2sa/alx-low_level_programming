#!/bin/bash
gcc *.c -fPIC -shared -o liball.so
