#include "main.h"
/**
 *  reset_to_98 - updates the value it points to to 98
 *  @n: integer value.
*/
void reset_to_98(int *n)
{
*n = 98;
}
