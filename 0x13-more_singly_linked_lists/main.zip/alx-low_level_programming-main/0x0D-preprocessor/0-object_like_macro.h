#ifndef _object_like_macro_h_
#define _object_like_macro_h_

#define SIZE 1024


#endif /* _object_like_macro_h_ */
