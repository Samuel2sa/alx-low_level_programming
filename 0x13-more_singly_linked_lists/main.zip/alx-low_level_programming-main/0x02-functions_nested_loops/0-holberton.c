/**
 * main - prints to string
 * Description: Prints positive, negative or zero
 * Return: 0
 */
#include <stdio.h>
int main(void)
{
printf("_putchar");
putchar ('\n');
return (0);
}
