#include "main.h"
/**
 * mul - function that prints the numbers, from 0 to 9, followed by a new line.
 * @a: the int for the paramaters of my function
 * @b: the int for the paramaters of my function
 * Return: 0
 */
int mul(int a, int b)
{
return (a * b);
}
