#ifndef HOLBERTON_H
#define HOLBERTON_H
#include <stdio.h>

int _isupper(int c);

#endif /* HOLBERTON_H */
